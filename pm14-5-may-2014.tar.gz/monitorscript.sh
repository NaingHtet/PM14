while true
do
tail -n 20 monitor.txt
sleep 1
clear
done
