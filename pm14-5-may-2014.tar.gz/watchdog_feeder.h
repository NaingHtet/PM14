/** @file watchdog_feeder.h
 *  @brief The header file for watchdog_feeder
 *
 *  @author Naing Minn Htet <naingminhtet91@gmail.com>
 */

void watchdog_feeder_initialize();
void *feed_watchdog(void *arg);